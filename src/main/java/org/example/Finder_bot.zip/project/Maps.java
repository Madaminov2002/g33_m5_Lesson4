package org.example.project;

import java.util.HashMap;
import java.util.Map;

public class Maps {
    public static final Map<Long,Steps> USER_STEPS=new HashMap<>();
    public static final Map<Long,PersonDetails> USER_INFORMATION=new HashMap<>();
}
