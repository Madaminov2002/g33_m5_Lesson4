package org.example.project;

public enum Steps {
    ID,
    FIRST_NAME,
    LAST_NAME,
    GENDER,
    PHONE_NUMBER,
    CITY,
    BIRTH_DATE,
    APP_FINISHED;
}
